/* 
*
 * @author Alex Rogério
 * @date 07/03/2017
 */


public class HappyObject extends MoodyObject {
    
    public void laugh(){
        System.out.println("hahahahahahhahahaha");
    }
    
   
    protected String getMood(){
        return "Feliz";
    }
 
}
